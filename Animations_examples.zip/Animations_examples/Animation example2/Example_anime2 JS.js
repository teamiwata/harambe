var start = Date.now();

var timer = setInterval(function() {

    var timePassed = Date.now() - start;

    if (timePassed >= 2000) {
        clearInterval(timer);
        return;
    }


    draw(timePassed);

}, 20);


function draw(timePassed) {
    train.style.left = timePassed / 5 + 'px';
}/**
 * Created by Ian on 2017-04-21.
 */
